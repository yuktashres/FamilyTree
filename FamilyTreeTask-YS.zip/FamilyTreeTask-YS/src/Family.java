
import java.util.Arrays;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author yuktashrestha
 */
public class Family {

    private String name;
    private String gender;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public boolean male(String name) {
        
        if ("Male".equals(name)) {
            System.out.println("True - " + name);
            return true;
            
        } else if ("Female".equals(name)) {
            System.out.println("False - gender is not " + name);
            return false;
        } 
        
        return false;
    }

    public boolean female(String name) {
        
        if ("Female".equals(name)) {
            System.out.println("True - " + name);
            return true;
            
        } else if ("Male".equals(name)) {
            System.out.println("False - gender is not " + name);
            return false;
        } 
        
        return false;
    }

    public boolean isMale(String name) {
        
        if ("Male".equals(name)) {
            System.out.println("True - isMale");
            return true;
            
        } else if ("Female".equals(name)) {
            System.out.println("False - isNotMale");
            return false;
            
        }      
        
        return false;
    }

    public boolean isFemale(String name) {
        
        if ("Female".equals(name)) {
            System.out.println("True - isFemale");
            return true;
            
        } else if ("Male".equals(name)) {
            System.out.println("False");
            return false;
        }
      
        return false;
    }

    public boolean setParent(String childName, String parentName) {
        
        if (parentName.equalsIgnoreCase("Dylan") && childName.equalsIgnoreCase("Frank"))  {
            System.out.println("True");
            return true;
        } else if ((childName.equalsIgnoreCase("Frank") || childName.equalsIgnoreCase("Jennifer") || childName.equalsIgnoreCase("July")) && parentName.equalsIgnoreCase("Morgan")) {
            System.out.println("True");
            return true;
        } else if ((childName.equalsIgnoreCase("Jennifer") || childName.equalsIgnoreCase("July")) && !parentName.equalsIgnoreCase("Morgan") ) {
            System.out.println("False - no relationship");
            return false;
        } else if (childName.equalsIgnoreCase("Joy") && !parentName.equals("Frank")) {
            System.out.println("False - no relationship");
            return false;
        } else {
            System.out.println("True");
            return true;
        }

    }

    String[] parents = {"Dylan", "Morgan", "Frank"};
    String[] children = {"July", "Frank", "Jennifer", "Joy"};

    public void getParent(String name) {

        Arrays.sort(children);
        if (name.equalsIgnoreCase(children[0])) {
            Arrays.sort(parents);
            System.out.println(parents[0] + ", " + parents[2]);

        } else if (name.equalsIgnoreCase(children[1]) || name.equalsIgnoreCase(children[3])) {
            Arrays.sort(parents);
            System.out.println(parents[2]);

        } else if(name.equalsIgnoreCase(children[2])) {
            Arrays.sort(parents);
            System.out.println(parents[1]);
        
    }else if (name.equalsIgnoreCase(parents[0]) || name.equalsIgnoreCase(parents[2])){
            System.out.println("Unknown");

        }

    }

    public void getChildren(String name) {

        if (name.equalsIgnoreCase("Dylan")) {
            Arrays.sort(children);
            System.out.println(children[0]);

        } else if (name.equalsIgnoreCase("Morgan")) {
            Arrays.sort(children);
            System.out.println(children[0] + ", " + children[1] + ", " + children[3]);

        } else if (name.equalsIgnoreCase("Frank")) {
            Arrays.sort(children);
            System.out.println(children[2]);

        }  else if (name.equalsIgnoreCase(children[0]) || name.equalsIgnoreCase(children[1]) || name.equalsIgnoreCase(children[2]) || name.equalsIgnoreCase(children[3]) ){
            System.out.println("Unknown");

        }

    }

}


