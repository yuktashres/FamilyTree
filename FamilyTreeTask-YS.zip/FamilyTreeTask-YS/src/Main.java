
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author yuktashrestha
 */
public class Main {

    public static void main(String[] args) {

        Family relation = new Family();

        Scanner scan = new Scanner(System.in);
        //input name
        System.out.println("Enter your name below.");
        String name = scan.nextLine();

        //gender
        String[] gender = {"Male", "Female"};
        Random rand = new Random();
        //define random gender
        int random = rand.nextInt(gender.length);
        System.out.println("Are you " + gender[random] + "?");

        //input actual gender
        System.out.println("Enter Male or Female.");
        String actualGender = scan.nextLine();

        //input names kids
        System.out.println("What is your childs name?");
        String child = scan.nextLine();

        //Display all information
        System.out.println("Details of " + name);
        System.out.println("Is " + name + "'s gender known?");

        //check if guessed gender and actual gender match
        //return true (match) or false (no match)
        if (gender[random].equalsIgnoreCase(actualGender) && !actualGender.equalsIgnoreCase("Male")) {
            relation.female(actualGender);
            relation.isFemale(actualGender);

        } else if (gender[random].equalsIgnoreCase(actualGender) && !actualGender.equalsIgnoreCase("Female")) {
            relation.male(actualGender);
            relation.isMale(actualGender);

        } else if (!gender[random].equalsIgnoreCase(actualGender) && actualGender.equalsIgnoreCase("Male")) {
            relation.male(gender[random]);
            relation.isMale(actualGender);

        } else if (!gender[random].equalsIgnoreCase(actualGender) && actualGender.equalsIgnoreCase("Female")) {
            relation.female(gender[random]);
            relation.isFemale(actualGender);

        } else if (actualGender.equals("")) {
            System.out.println("False - unknown!");
        }
        
        
        //boolean setParents 
        relation.setParent(child, name);
        //display parents names
        System.out.println("Parents of " + name + ":");
        relation.getParent(name);

        //display children names
        System.out.println("Children of " + name + ":");
        relation.getChildren(name);

    }
}
